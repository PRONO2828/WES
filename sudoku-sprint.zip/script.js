const boardElement = document.getElementById("board");
const timerElement = document.getElementById("timer");
const mistakesElement = document.getElementById("mistakes");
const messageElement = document.getElementById("message");
const difficultyElement = document.getElementById("difficulty");
const newGameButton = document.getElementById("new-game");
const checkButton = document.getElementById("check-button");
const noteToggleButton = document.getElementById("note-toggle");
const numberPad = document.getElementById("number-pad");

const difficultyMap = {
  easy: 36,
  medium: 46,
  hard: 54,
};

const state = {
  solution: [],
  puzzle: [],
  board: [],
  fixed: [],
  notes: Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set())),
  selected: null,
  noteMode: false,
  mistakes: 0,
  seconds: 0,
  intervalId: null,
  gameComplete: false,
};

function createEmptyBoard() {
  return Array.from({ length: 9 }, () => Array(9).fill(0));
}

function shuffle(values) {
  const copy = [...values];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function isPlacementValid(board, row, col, value) {
  for (let index = 0; index < 9; index += 1) {
    if (board[row][index] === value || board[index][col] === value) {
      return false;
    }
  }

  const boxRow = Math.floor(row / 3) * 3;
  const boxCol = Math.floor(col / 3) * 3;

  for (let r = boxRow; r < boxRow + 3; r += 1) {
    for (let c = boxCol; c < boxCol + 3; c += 1) {
      if (board[r][c] === value) {
        return false;
      }
    }
  }

  return true;
}

function solveBoard(board) {
  for (let row = 0; row < 9; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      if (board[row][col] !== 0) {
        continue;
      }

      for (const value of shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9])) {
        if (!isPlacementValid(board, row, col, value)) {
          continue;
        }

        board[row][col] = value;
        if (solveBoard(board)) {
          return true;
        }
        board[row][col] = 0;
      }

      return false;
    }
  }

  return true;
}

function generateSolvedBoard() {
  const board = createEmptyBoard();
  solveBoard(board);
  return board;
}

function cloneBoard(board) {
  return board.map((row) => [...row]);
}

function generatePuzzle(solution, cellsToRemove) {
  const puzzle = cloneBoard(solution);
  const positions = shuffle(Array.from({ length: 81 }, (_, index) => index));

  for (let i = 0; i < cellsToRemove; i += 1) {
    const position = positions[i];
    const row = Math.floor(position / 9);
    const col = position % 9;
    puzzle[row][col] = 0;
  }

  return puzzle;
}

function formatTime(seconds) {
  const minutes = String(Math.floor(seconds / 60)).padStart(2, "0");
  const secs = String(seconds % 60).padStart(2, "0");
  return `${minutes}:${secs}`;
}

function resetTimer() {
  if (state.intervalId) {
    clearInterval(state.intervalId);
  }

  state.seconds = 0;
  timerElement.textContent = formatTime(0);
  state.intervalId = window.setInterval(() => {
    state.seconds += 1;
    timerElement.textContent = formatTime(state.seconds);
  }, 1000);
}

function updateMessage(text, tone = "") {
  messageElement.textContent = text;
  messageElement.className = `message ${tone}`.trim();
}

function clearInvalidHighlights() {
  document.querySelectorAll(".cell.invalid").forEach((cell) => {
    cell.classList.remove("invalid");
  });
}

function renderBoard() {
  boardElement.innerHTML = "";

  for (let row = 0; row < 9; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "cell";
      button.setAttribute("role", "gridcell");
      button.setAttribute("aria-label", `Row ${row + 1} column ${col + 1}`);
      button.dataset.row = String(row);
      button.dataset.col = String(col);

      if ((col + 1) % 3 === 0 && col !== 8) {
        button.classList.add("border-right");
      }
      if ((row + 1) % 3 === 0 && row !== 8) {
        button.classList.add("border-bottom");
      }

      if (state.fixed[row][col]) {
        button.classList.add("fixed");
        button.textContent = String(state.board[row][col]);
      } else if (state.board[row][col] !== 0) {
        button.textContent = String(state.board[row][col]);
      } else if (state.notes[row][col].size > 0) {
        button.classList.add("notes");
        const notesGrid = document.createElement("div");
        notesGrid.className = "notes-grid";
        for (let value = 1; value <= 9; value += 1) {
          const noteValue = document.createElement("span");
          noteValue.className = "note-value";
          noteValue.textContent = state.notes[row][col].has(value) ? String(value) : "";
          notesGrid.appendChild(noteValue);
        }
        button.appendChild(notesGrid);
      }

      if (state.selected && state.selected.row === row && state.selected.col === col) {
        button.classList.add("selected");
      }

      if (state.selected) {
        const sameRow = state.selected.row === row;
        const sameCol = state.selected.col === col;
        const sameBox =
          Math.floor(state.selected.row / 3) === Math.floor(row / 3) &&
          Math.floor(state.selected.col / 3) === Math.floor(col / 3);

        if ((sameRow || sameCol || sameBox) && !(sameRow && sameCol)) {
          button.classList.add("related");
        }
      }

      boardElement.appendChild(button);
    }
  }
}

function selectCell(row, col) {
  state.selected = { row, col };
  renderBoard();
}

function toggleNoteMode() {
  state.noteMode = !state.noteMode;
  noteToggleButton.textContent = state.noteMode ? "Notes On" : "Notes Off";
  noteToggleButton.classList.toggle("active-toggle", state.noteMode);
  updateMessage(state.noteMode ? "Note mode is on. Tap digits to pencil them in." : "Note mode is off. Enter full values normally.");
}

function isBoardSolved() {
  for (let row = 0; row < 9; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      if (state.board[row][col] !== state.solution[row][col]) {
        return false;
      }
    }
  }
  return true;
}

function finishGame() {
  state.gameComplete = true;
  if (state.intervalId) {
    clearInterval(state.intervalId);
  }
  updateMessage(`You solved it in ${formatTime(state.seconds)} with ${state.mistakes} mistake${state.mistakes === 1 ? "" : "s"}.`, "success");
}

function handleValueInput(rawValue) {
  if (!state.selected || state.gameComplete) {
    updateMessage("Pick an empty cell first.");
    return;
  }

  const { row, col } = state.selected;
  if (state.fixed[row][col]) {
    updateMessage("That number is locked in. Choose another cell.");
    return;
  }

  clearInvalidHighlights();

  if (rawValue === "clear") {
    state.board[row][col] = 0;
    state.notes[row][col].clear();
    renderBoard();
    updateMessage("Cell cleared.");
    return;
  }

  const value = Number(rawValue);
  if (state.noteMode) {
    if (state.board[row][col] !== 0) {
      state.board[row][col] = 0;
    }

    if (state.notes[row][col].has(value)) {
      state.notes[row][col].delete(value);
    } else {
      state.notes[row][col].add(value);
    }

    renderBoard();
    updateMessage(`Updated notes for row ${row + 1}, column ${col + 1}.`);
    return;
  }

  state.notes[row][col].clear();
  state.board[row][col] = value;
  renderBoard();

  if (value !== state.solution[row][col]) {
    state.mistakes += 1;
    mistakesElement.textContent = String(state.mistakes);
    const cell = boardElement.querySelector(`[data-row="${row}"][data-col="${col}"]`);
    if (cell) {
      cell.classList.add("invalid");
    }
    updateMessage("That value doesn't fit there. Try another number.", "error");
    return;
  }

  updateMessage("Nice move. Keep going.");

  if (isBoardSolved()) {
    finishGame();
  }
}

function checkBoard() {
  clearInvalidHighlights();

  let invalidCount = 0;
  for (let row = 0; row < 9; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      const value = state.board[row][col];
      if (value === 0 || value === state.solution[row][col]) {
        continue;
      }
      invalidCount += 1;
      const cell = boardElement.querySelector(`[data-row="${row}"][data-col="${col}"]`);
      if (cell) {
        cell.classList.add("invalid");
      }
    }
  }

  if (invalidCount === 0) {
    updateMessage("No conflicts found right now.", "success");
  } else {
    updateMessage(`${invalidCount} cell${invalidCount === 1 ? "" : "s"} need another look.`, "error");
  }
}

function createGame() {
  state.solution = generateSolvedBoard();
  state.puzzle = generatePuzzle(state.solution, difficultyMap[difficultyElement.value]);
  state.board = cloneBoard(state.puzzle);
  state.fixed = state.puzzle.map((row) => row.map((value) => value !== 0));
  state.notes = Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set()));
  state.selected = null;
  state.mistakes = 0;
  state.gameComplete = false;
  mistakesElement.textContent = "0";
  clearInvalidHighlights();
  resetTimer();
  renderBoard();
  updateMessage("New puzzle ready. Select a cell and start solving.");
}

boardElement.addEventListener("click", (event) => {
  const cell = event.target.closest(".cell");
  if (!cell) {
    return;
  }

  selectCell(Number(cell.dataset.row), Number(cell.dataset.col));
});

numberPad.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-value]");
  if (!button) {
    return;
  }

  handleValueInput(button.dataset.value);
});

noteToggleButton.addEventListener("click", toggleNoteMode);
checkButton.addEventListener("click", checkBoard);
newGameButton.addEventListener("click", createGame);
difficultyElement.addEventListener("change", createGame);

window.addEventListener("keydown", (event) => {
  if (event.key >= "1" && event.key <= "9") {
    handleValueInput(event.key);
  }

  if (event.key === "Backspace" || event.key === "Delete" || event.key === "0") {
    handleValueInput("clear");
  }

  if (event.key.toLowerCase() === "n") {
    toggleNoteMode();
  }
});

createGame();
